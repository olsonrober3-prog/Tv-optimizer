package com.tvoptimizer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.File
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 20, 33)
    private val panel = Color.rgb(27, 39, 57)
    private val accent = Color.rgb(58, 190, 160)
    private val muted = Color.rgb(170, 185, 202)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showHome()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    private fun base(title: String, subtitle: String? = null) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(32), dp(22), dp(32), dp(22))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val heading = TextView(this).apply {
            text = title
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(heading)
        if (subtitle != null) content.addView(TextView(this).apply {
            text = subtitle; textSize = 15f; setTextColor(muted)
            setPadding(0, dp(5), 0, dp(18))
        })
        root.addView(content)
        scroll.addView(root)
        setContentView(scroll)
        root = content
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            textSize = 17f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
            setPadding(dp(18), dp(12), dp(18), dp(12))
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, dp(58)).apply {
            bottomMargin = dp(10)
        })
    }

    private fun infoCard(title: String, value: String, detail: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            setBackgroundColor(panel)
        }
        box.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(muted) })
        box.addView(TextView(this).apply {
            text = value; textSize = 25f; setTextColor(accent)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        box.addView(TextView(this).apply { text = detail; textSize = 13f; setTextColor(muted) })
        root.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun bytes(n: Long): String {
        val gb = n / (1024.0 * 1024 * 1024)
        return if (gb >= 1) String.format("%.2f GB", gb) else String.format("%.0f MB", n / (1024.0 * 1024))
    }

    private fun showHome() {
        base("TV Optimizer", "Mantenimiento sencillo para tu TV Box")
        val runtime = Runtime.getRuntime()
        val totalRam = runtime.maxMemory()
        val usedRam = runtime.totalMemory() - runtime.freeMemory()
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.blockCountLong * stat.blockSizeLong
        val free = stat.availableBlocksLong * stat.blockSizeLong
        infoCard("Memoria de la aplicación (estimada)", bytes(usedRam), "Límite de memoria de esta app: ${bytes(totalRam)}")
        infoCard("Almacenamiento interno", bytes(total - free) + " usados", "${bytes(free)} disponibles de ${bytes(total)}")
        infoCard("Dispositivo", android.os.Build.MODEL ?: "TV Box", "Android ${android.os.Build.VERSION.RELEASE} · API ${android.os.Build.VERSION.SDK_INT}")
        button("Administrar aplicaciones") { showApps() }
        button("Abrir ajustes de almacenamiento") { openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }
        button("Abrir ajustes de Android") { openSettings(Settings.ACTION_SETTINGS) }
        button("Actualizar diagnóstico") { showHome() }
        root.addView(TextView(this).apply {
            text = "Nota: Android limita la limpieza de caché y RAM de otras apps. TV Optimizer no fuerza cierres ni borra datos privados."
            setTextColor(muted); textSize = 13f; setPadding(0, dp(10), 0, 0)
        })
        root.getChildAt(1)?.requestFocus()
    }

    private fun openSettings(action: String) {
        try { startActivity(Intent(action)) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }

    private fun showApps() {
        base("Aplicaciones instaladas", "Selecciona una aplicación para ver sus opciones")
        button("← Volver al inicio") { showHome() }
        val pm = packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.packageName != packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        for (app in apps) {
            val name = pm.getApplicationLabel(app).toString()
            val isSystem = (app.flags and ApplicationInfo.FLAG_SYSTEM) != 0
            button((if (isSystem) "⚙  " else "●  ") + name + if (isSystem) "  · Sistema" else "") {
                appOptions(app, name, isSystem)
            }
        }
        if (apps.isEmpty()) root.addView(TextView(this).apply {
            text = "No se encontraron aplicaciones."; setTextColor(Color.WHITE)
        })
    }

    private fun appOptions(app: ApplicationInfo, name: String, isSystem: Boolean) {
        val choices = mutableListOf("Abrir información de la aplicación")
        if (!isSystem) choices.add("Solicitar desinstalación")
        AlertDialog.Builder(this)
            .setTitle(name)
            .setItems(choices.toTypedArray()) { _, which ->
                if (which == 0) {
                    try {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.packageName}")))
                    } catch (_: Exception) { }
                } else {
                    try {
                        startActivity(Intent(Intent.ACTION_DELETE,
                            Uri.parse("package:${app.packageName}")))
                    } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.packageName}")))
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
