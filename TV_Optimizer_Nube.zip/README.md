# TV Optimizer — versión inicial

Aplicación Android nativa en Kotlin para TV Box con Android 10/11.

## Funciones incluidas
- Diagnóstico básico del dispositivo.
- Estimación de memoria de proceso y almacenamiento interno disponible.
- Lista de aplicaciones instaladas.
- Acceso a la ficha de cada app en Ajustes.
- Solicitud de desinstalación para aplicaciones no marcadas como sistema.
- Navegación mediante botones enfocables compatibles con control remoto.

## Limitaciones importantes
Android no permite a una app normal limpiar la caché privada de otras aplicaciones, terminar procesos ajenos ni desinstalar apps silenciosamente. La desinstalación se confirma en la interfaz del sistema. La memoria mostrada corresponde al proceso de TV Optimizer, no a la RAM total del equipo.

## Compilar APK
1. Instala Android Studio (Giraffe o posterior) en una computadora.
2. Abre la carpeta `TVOptimizer`.
3. Espera la sincronización de Gradle.
4. Selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
5. El APK estará en `app/build/outputs/apk/debug/app-debug.apk`.

SDK requerido: compileSdk 34. minSdk 23, targetSdk 32.

## Compilar APK en la nube (sin instalar Android Studio)

1. Crea un repositorio nuevo en GitHub desde el navegador.
2. Sube el contenido de esta carpeta (incluida la carpeta oculta `.github`).
3. Abre la pestaña **Actions** del repositorio.
4. Ejecuta **Build TV Optimizer APK** con **Run workflow**, o espera a que termine el flujo al subir los archivos.
5. Abre la ejecución terminada y descarga el artefacto **TV-Optimizer-APK**.
6. Extrae el ZIP descargado: dentro estará `app-debug.apk`. Pásalo al TV Box e instálalo.

El APK de depuración se puede instalar, pero no está firmado como versión de publicación. Android puede mostrar una advertencia al instalarlo desde fuera de Play Store. Revisa el origen antes de instalar.
